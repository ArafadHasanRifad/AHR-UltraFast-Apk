# AHR UltraFast Mobile — Android prototype v0.1

**Target:** Android 13 / POCO F5 Snapdragon 7+ Gen 2. Supports Android 8+ but only Android 13 has been selected as design target; **not tested on a real device**.

## Reality of export speed

- **No effects and unchanged codecs:** Media3 Transformer can use transmuxing / copying encoded audio/video samples, avoiding full re-encoding. This still takes storage I/O time. Trim optimization is attempted, but may fail and fall back to ordinary encoding.
- **Visible text/logo or clone-patch:** the whole output video must be rendered/re-encoded using MediaCodec and OpenGL. This can take a long time for 5–9 hours of content, even with Snapdragon hardware acceleration; no guarantee of minutes-long export.
- **GPU clone patch** is **not AI inpainting** or blur. The shader replaces selected pixels with live neighboring pixels every frame. It can be effective on stationary/simple backgrounds if the patch comes from clean content; moving detailed backgrounds may look wrong.

## Features in this source package

- Pick local video and transparent PNG/logo using Android Storage Access Framework (no massive source-file copy).
- On-device seekable video preview with touch rectangle to select delogo area.
- Optional HH:MM:SS trim. Unchanged clips attempt fast stream-copy/optimized trim.
- Add static PNG logo (top right) and/or text watermark (bottom left).
- Experimental GPU clone patch over a manually selected rectangle, with configurable X/Y sample shift.
- Foreground-service export, progress percent & ETA, notification and cancellation.
- Output stored once in app's external Movies directory and can be shared using Android's share sheet.
- Remembers last successful export path across Activity restarts.

## Limitations and risks (v0.1)

- No compiled APK is included, because this environment cannot run Android SDK/Gradle. Source code is **uncompiled/unverified**. Build and test on a short MP4 first.
- Output is stored under `Android/data/com.ahr.ultrafast/files/Movies/`; use **Share finished video** to move it to a more permanent place. Uninstalling the app may remove app-specific files. **Save finished videos elsewhere before uninstalling.**
- No automatic AI object tracking, no AI inpainting, no per-clip selective rendering, no SRT editor, no cut/merge, no editing timeline and no batch queue yet.
- Media3 works best with supported local media. Complex variable frame rate, HDR and uncommon codec combinations may fail or render differently. Unsupported data sources may fail.
- On some Android versions, foreground service execution can be restricted/limited; the OS can terminate long jobs. A partial unsuccessful output is deleted.
- No stable guarantee of full-quality originals after hardware re-encoding. Normal MP4 output may not preserve embedded subtitle and miscellaneous tracks.
- Applying clone patch to content you do not own may infringe rights; only modify content you have permission to edit.

## Build in Android Studio

1. Extract this ZIP and open the root `AHR_UltraFast_Mobile` project in Android Studio.
2. Use JDK 17. Let Gradle install Android SDK 36 and resolve dependencies (internet required).
3. Build > Build APK(s) or run `gradle :app:assembleDebug` with Gradle 8.13.
4. Install the resulting `app/build/outputs/apk/debug/app-debug.apk` on your POCO F5.
5. Allow notifications for export progress, then select an MP4 (test with 30 seconds first).

## Completely browser-only build (phone is enough)

1. On GitHub, create a repo; upload the **individual project files** from this extracted ZIP (preserve the directories, including `.github/workflows/android.yml`).
2. Open your repo's Actions tab, run **Build Android debug APK** (or push to main).
3. Open the completed workflow run > Artifacts > `AHR-UltraFast-Mobile-DEBUG-APK` > download and install.

Alternative phone-friendly workflow: see separately provided `Phone_Only_APK_Build.yml` and `Phone_Only_GitHub_Instructions.txt`. This only requires uploading `AHR_UltraFast_Mobile_Source.zip` into the repository and creating a workflow file.

## Security / privacy

The app uses the system video/image picker. It does not upload files or use external server APIs. Debug APK is not Play Store production-signed.

## Key sources

- https://developer.android.com/media/media3/transformer/getting-started
- https://developer.android.com/media/media3/transformer/transformations
- https://developer.android.com/media/media3/transformer/troubleshooting
- https://developer.android.com/jetpack/androidx/releases/media3
