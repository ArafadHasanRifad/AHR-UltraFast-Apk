package com.ahr.ultrafast;

import android.content.Context;
import android.opengl.GLES20;
import androidx.media3.common.VideoFrameProcessingException;
import androidx.media3.common.util.GlProgram;
import androidx.media3.common.util.GlUtil;
import androidx.media3.common.util.Size;
import androidx.media3.common.util.UnstableApi;
import androidx.media3.effect.BaseGlShaderProgram;
import androidx.media3.effect.GlEffect;
import java.io.IOException;

/** A cheap, per-frame GPU clone stamp. It is NOT scene-aware / AI inpainting. */
@UnstableApi
public final class ClonePatchEffect implements GlEffect {
    private final float x, y, w, h, shiftX, shiftY;
    public ClonePatchEffect(float x, float y, float w, float h, float shiftX, float shiftY) {
        this.x=x; this.y=y; this.w=w; this.h=h; this.shiftX=shiftX; this.shiftY=shiftY;
    }
    @Override public BaseGlShaderProgram toGlShaderProgram(Context ctx, boolean useHdr) throws VideoFrameProcessingException {
        return new Shader(ctx, useHdr, new float[]{x,y,w,h}, new float[]{shiftX,shiftY});
    }
    private static final class Shader extends BaseGlShaderProgram {
        private final GlProgram program;
        Shader(Context context, boolean hdr, float[] rect, float[] shift) throws VideoFrameProcessingException {
            super(hdr, 1);
            try {
                program = new GlProgram(context, R.raw.ahr_vertex, R.raw.ahr_clone);
                program.setBufferAttribute("aFramePosition", GlUtil.getNormalizedCoordinateBounds(), GlUtil.HOMOGENEOUS_COORDINATE_VECTOR_SIZE);
                float[] id = GlUtil.create4x4IdentityMatrix();
                program.setFloatsUniform("uTransformationMatrix", id);
                program.setFloatsUniform("uTexTransformationMatrix", id);
                program.setFloatsUniform("uRect", rect);
                program.setFloatsUniform("uShift", shift);
            } catch (IOException | GlUtil.GlException e) { throw new VideoFrameProcessingException(e); }
        }
        @Override public Size configure(int width, int height) { return new Size(width,height); }
        @Override public void drawFrame(int tex, long timeUs) throws VideoFrameProcessingException {
            try {
                program.use();
                program.setSamplerTexIdUniform("uTexSampler", tex, 0);
                program.bindAttributesAndUniforms();
                GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP, 0, 4);
            } catch (GlUtil.GlException e) { throw new VideoFrameProcessingException(e, timeUs); }
        }
        @Override public void release() throws VideoFrameProcessingException {
            super.release();
            try { program.delete(); } catch (GlUtil.GlException e) { throw new VideoFrameProcessingException(e); }
        }
    }
}
