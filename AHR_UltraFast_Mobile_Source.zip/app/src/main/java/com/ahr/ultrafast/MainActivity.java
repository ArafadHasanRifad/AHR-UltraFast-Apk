package com.ahr.ultrafast;

import android.Manifest;
import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.media.MediaMetadataRetriever;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.DocumentsContract;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.SeekBar;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.VideoView;
import androidx.core.content.ContextCompat;
import androidx.core.content.FileProvider;
import java.io.File;
import java.util.Locale;

/** Single screen editor. Input never duplicated; share exported file from app's Movies folder. */
public final class MainActivity extends Activity {
    private static final int PICK_VIDEO = 10, PICK_LOGO = 11;
    private final int BG = 0xFF0B111F, CARD = 0xFF182338, MUTED = 0xFFB1C1D5, ACCENT = 0xFF46D9BC;
    private Uri sourceUri, logoUri;
    private String sourceName = "Video";
    private long durationSeconds = 0;
    private int displayedWidth = 16, displayedHeight = 9;
    private TextView sourceTitle, durationText, logoName, progressInfo;
    private EditText startField, endField, watermark, left, top, width, height, shiftX, shiftY;
    private CheckBox cloneEnabled;
    private ProgressBar progressBar;
    private VideoView preview;
    private SeekBar previewSeek;
    private SelectionOverlay selection;
    private Button share;
    private String finishedPath;

    private final BroadcastReceiver updateReceiver = new BroadcastReceiver() {
        @Override public void onReceive(Context context, Intent intent) {
            String message = intent.getStringExtra("message");
            progressInfo.setText(message == null ? "" : message);
            int percent = intent.getIntExtra("percent",-1);
            progressBar.setIndeterminate(percent < 0);
            if (percent >= 0) progressBar.setProgress(percent);
            String path = intent.getStringExtra("path");
            if (path != null) { finishedPath = path; share.setEnabled(true); }
        }
    };

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        buildUi();
        restoreLastExport();
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 100);
        }
    }

    @Override protected void onStart() {
        super.onStart();
        restoreLastExport();
        IntentFilter filter = new IntentFilter(ExportService.STATUS);
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(updateReceiver, filter, Context.RECEIVER_NOT_EXPORTED);
        else registerReceiver(updateReceiver,filter);
    }
    @Override protected void onStop() { unregisterReceiver(updateReceiver); super.onStop(); }
    @Override protected void onDestroy() { if (preview != null) preview.stopPlayback(); super.onDestroy(); }

    private void buildUi() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(BG);
        LinearLayout column = new LinearLayout(this);
        column.setOrientation(LinearLayout.VERTICAL);
        column.setPadding(dp(18), dp(16), dp(18), dp(26));
        scroll.addView(column);
        setContentView(scroll);

        TextView title = label("AHR UltraFast",28,Color.WHITE);
        title.setTypeface(null,1); column.addView(title);
        TextView sub = label("MOBILE EDITOR  •  LONG VIDEO FIRST",12,ACCENT); column.addView(sub);
        gap(column,16);

        Button choose = button("1  Choose video", ACCENT);
        choose.setOnClickListener(v -> pick("video/*", PICK_VIDEO)); column.addView(choose);
        sourceTitle = label("No video selected",15,Color.WHITE); column.addView(sourceTitle);
        durationText = label("MP4 / supported video formats",12,MUTED); column.addView(durationText);
        gap(column,10);

        FrameLayout panel = new FrameLayout(this);
        panel.setBackgroundColor(Color.BLACK);
        column.addView(panel, new LinearLayout.LayoutParams(-1,dp(215)));
        preview = new VideoView(this);
        panel.addView(preview,new FrameLayout.LayoutParams(-1,-1));
        selection = new SelectionOverlay(this);
        panel.addView(selection,new FrameLayout.LayoutParams(-1,-1));
        selection.setEnabled(false);
        gap(column,6);
        previewSeek = new SeekBar(this);
        previewSeek.setMax(1000);
        previewSeek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar bar, int progress, boolean fromUser) {
                if (fromUser && sourceUri != null && durationSeconds > 0) {
                    preview.seekTo((int)Math.min(Integer.MAX_VALUE, durationSeconds * 1000L * progress / 1000L));
                }
            }
            @Override public void onStartTrackingTouch(SeekBar bar) {}
            @Override public void onStopTrackingTouch(SeekBar bar) {}
        });
        column.addView(previewSeek);
        TextView previewNote = label("Preview: drag a rectangle to select a logo when Clone patch is enabled. The GPU effect is applied only during export.",12,MUTED);
        column.addView(previewNote);
        gap(column,14);

        section(column,"2  FAST TRIM");
        LinearLayout timing = twoColumn(); column.addView(timing);
        startField = field("Start HH:MM:SS", "00:00:00");
        endField = field("End HH:MM:SS (0 = end)", "00:00:00");
        timing.addView(startField,new LinearLayout.LayoutParams(0,dp(58),1));
        timing.addView(endField,new LinearLayout.LayoutParams(0,dp(58),1));
        column.addView(label("Without overlays or clone, the app attempts stream copying instead of rendering all frames.",12,MUTED));
        gap(column,12);

        section(column,"3  BRANDING");
        watermark = field("Optional text watermark", ""); column.addView(watermark);
        Button pickLogo = button("Choose transparent PNG logo", CARD); column.addView(pickLogo);
        pickLogo.setOnClickListener(v -> pick("image/*",PICK_LOGO));
        logoName = label("No logo selected",12,MUTED); column.addView(logoName);
        Button clearLogo = button("Remove selected logo",CARD);
        clearLogo.setOnClickListener(v->{logoUri=null;logoName.setText("No logo selected");}); column.addView(clearLogo);
        gap(column,12);

        section(column,"4  DELOGO • GPU CLONE PATCH");
        cloneEnabled = new CheckBox(this);
        cloneEnabled.setText("Enable non-blur patch cloning");
        cloneEnabled.setTextColor(Color.WHITE);
        column.addView(cloneEnabled);
        cloneEnabled.setOnCheckedChangeListener((b,on)->{ selection.setEnabled(on); selection.invalidate(); });
        column.addView(label("Replaces pixels in the selected region using live pixels from a nearby region in every frame. Best on similar backgrounds. Not scene-aware AI removal.",12,MUTED));
        LinearLayout rowA = fourColumn(); column.addView(rowA);
        left = field("Left %", "83"); top = field("Top %", "2"); width=field("Width %", "14"); height=field("Height %", "8");
        for (EditText box : new EditText[]{left,top,width,height}) rowA.addView(box,new LinearLayout.LayoutParams(0,dp(55),1));
        LinearLayout rowB = twoColumn(); column.addView(rowB);
        shiftX=field("Clone source X shift %", "-18");
        shiftY=field("Clone source Y shift %", "0");
        rowB.addView(shiftX,new LinearLayout.LayoutParams(0,dp(56),1));
        rowB.addView(shiftY,new LinearLayout.LayoutParams(0,dp(56),1));
        column.addView(label("Tip: move the source shift away from the unwanted logo. A matching clean background is necessary.",12,MUTED));
        gap(column,14);

        section(column,"5  EXPORT");
        progressInfo = label("Ready. Only compatible unchanged streams can be saved ultra-fast.",13,MUTED);
        column.addView(progressInfo);
        progressBar = new ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal);
        progressBar.setMax(100);
        column.addView(progressBar,new LinearLayout.LayoutParams(-1,dp(12)));
        gap(column,6);
        Button export = button("START EXPORT",ACCENT);
        export.setTextColor(Color.BLACK);
        export.setOnClickListener(v->startExport()); column.addView(export);
        Button cancel=button("Cancel export",CARD);
        cancel.setOnClickListener(v->startService(new Intent(this,ExportService.class).setAction(ExportService.CANCEL)));
        column.addView(cancel);
        share=button("Share finished video",CARD);share.setEnabled(false);
        share.setOnClickListener(v->shareResult());column.addView(share);
        gap(column,12);
        column.addView(label("Files export to app-specific external Movies storage; Share sends the file elsewhere. Keep enough free storage for the output, and test a short clip first. Android may stop long-running jobs due to device or OS limits.",12,MUTED));

        selection.onRectangle = (x,y,w,h)->{
            left.setText(pct(x)); top.setText(pct(y)); width.setText(pct(w)); height.setText(pct(h));
        };
    }

    private String pct(float f) { return String.format(Locale.US,"%.1f", f*100f); }
    private int dp(float f){ return (int)(f*getResources().getDisplayMetrics().density+.5f); }
    private void gap(LinearLayout layout,int height){View spacer=new View(this);layout.addView(spacer,new LinearLayout.LayoutParams(1,dp(height)));}
    private TextView label(String s,int size,int color){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);t.setPadding(dp(2),dp(3),dp(2),dp(4));return t;}
    private void section(LinearLayout parent,String s){TextView t=label(s,15,ACCENT);t.setTypeface(null,1);parent.addView(t);}
    private Button button(String text,int color){Button b=new Button(this);b.setText(text);b.setAllCaps(false);b.setTextColor(Color.WHITE);b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(color));return b;}
    private EditText field(String hint,String value){EditText t=new EditText(this);t.setSingleLine(true);t.setTextColor(Color.WHITE);t.setHintTextColor(MUTED);t.setHint(hint);t.setText(value.trim());t.setTextSize(13);t.setPadding(dp(8),dp(6),dp(8),dp(6));return t;}
    private LinearLayout twoColumn(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.HORIZONTAL);l.setBackgroundColor(CARD);return l;}
    private LinearLayout fourColumn(){return twoColumn();}

    private void pick(String mime,int request){
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType(mime);
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
        startActivityForResult(i,request);
    }
    @Override protected void onActivityResult(int req,int result,Intent data){
        super.onActivityResult(req,result,data);
        if(result!=RESULT_OK || data==null || data.getData()==null)return;
        Uri uri=data.getData();
        try{getContentResolver().takePersistableUriPermission(uri,Intent.FLAG_GRANT_READ_URI_PERMISSION);}catch(Exception ignored){}
        if(req==PICK_LOGO){logoUri=uri;logoName.setText(uri.getLastPathSegment());return;}
        if(req==PICK_VIDEO){
            sourceUri=uri;sourceName=uri.getLastPathSegment()==null?"video":uri.getLastPathSegment();
            sourceTitle.setText(sourceName);
            preview.setVideoURI(uri);
            preview.setOnPreparedListener(player->{player.setLooping(false);preview.seekTo(500);});
            try(MediaMetadataRetriever retriever=new MediaMetadataRetriever()){
                retriever.setDataSource(this,uri);
                String len=retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION);
                durationSeconds=len==null?0:Long.parseLong(len)/1000L;
                String w=retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH);
                String h=retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT);
                String r=retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION);
                displayedWidth=w==null?16:Integer.parseInt(w);
                displayedHeight=h==null?9:Integer.parseInt(h);
                if(r!=null&&(Integer.parseInt(r)%180!=0)){int temp=displayedWidth;displayedWidth=displayedHeight;displayedHeight=temp;}
                selection.videoWidth=displayedWidth;selection.videoHeight=displayedHeight;selection.invalidate();
                previewSeek.setProgress(0);
                durationText.setText("Duration: "+clock(durationSeconds)+"  •  "+displayedWidth+" × "+displayedHeight);
            }catch(Exception e){durationText.setText("Duration unavailable: "+e.getMessage());}
        }
    }

    private static String clock(long time){return String.format(Locale.US,"%02d:%02d:%02d",time/3600,(time/60)%60,time%60);}
    private int seconds(String s){
        String[] bits=s.trim().split(":");
        try{int n=0;for(String bit:bits){n=n*60+Integer.parseInt(bit.trim());}return Math.max(0,n);}catch(Exception e){throw new IllegalArgumentException("Use HH:MM:SS for trim times");}
    }
    private float percent(EditText box,float defaultValue){
        try{return Float.parseFloat(box.getText().toString().trim())/100f;}catch(Exception e){return defaultValue;}
    }

    private void startExport(){
        if(sourceUri==null){progressInfo.setText("Choose a video first");return;}
        try{
            int start=seconds(startField.getText().toString());
            int end=seconds(endField.getText().toString());
            if(end>0&&end<=start)throw new IllegalArgumentException("End must be after start");
            if(durationSeconds>0 && start>=durationSeconds)throw new IllegalArgumentException("Start is beyond the video duration");
            float x=percent(left,.83f),y=percent(top,.02f),w=percent(width,.14f),h=percent(height,.08f);
            float dx=percent(shiftX,-.18f),dy=percent(shiftY,0);
            if(cloneEnabled.isChecked() && (x<0||y<0||w<=0||h<=0||x+w>1||y+h>1))throw new IllegalArgumentException("Delogo rectangle must be inside 0–100%");
            Intent i=new Intent(this,ExportService.class).setAction(ExportService.START);
            i.putExtra("source",sourceUri.toString()).putExtra("name",sourceName)
                    .putExtra("trimStart",start).putExtra("trimEnd",end)
                    .putExtra("text",watermark.getText().toString().trim())
                    .putExtra("logo",logoUri==null?"":logoUri.toString())
                    .putExtra("clone",cloneEnabled.isChecked())
                    .putExtra("x",x).putExtra("y",y).putExtra("w",w).putExtra("h",h)
                    .putExtra("dx",dx).putExtra("dy",dy);
            finishedPath=null; share.setEnabled(false);
            getSharedPreferences("ahr", MODE_PRIVATE).edit().remove("lastPath").apply();
            progressBar.setIndeterminate(true);progressInfo.setText("Starting export…");
            ContextCompat.startForegroundService(this,i);
        }catch(Exception e){progressInfo.setText("Check settings: "+e.getMessage());}
    }

    private void restoreLastExport() {
        String path = getSharedPreferences("ahr", MODE_PRIVATE).getString("lastPath", null);
        if (path != null && new File(path).exists()) {
            finishedPath = path;
            if (share != null) share.setEnabled(true);
        }
    }

    private void shareResult(){
        if(finishedPath==null)return;
        File file=new File(finishedPath);
        if(!file.exists()){progressInfo.setText("Exported file not found");return;}
        Uri uri=FileProvider.getUriForFile(this,getPackageName()+".fileprovider",file);
        Intent send=new Intent(Intent.ACTION_SEND);
        send.setType("video/mp4");send.putExtra(Intent.EXTRA_STREAM,uri);
        send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        startActivity(Intent.createChooser(send,"Save or share exported video"));
    }

    private static final class SelectionOverlay extends View {
        private float x=.83f,y=.02f,w=.14f,h=.08f;
        int videoWidth=16,videoHeight=9;
        private final Paint paint=new Paint(3);
        private float downX,downY;
        interface RectListener {void onSelection(float x,float y,float w,float h);}
        RectListener onRectangle;
        SelectionOverlay(Context c){super(c);setLayerType(View.LAYER_TYPE_SOFTWARE,null);}
        private RectF area(){
            float vw=Math.max(1,videoWidth),vh=Math.max(1,videoHeight);
            float scale=Math.min(getWidth()/vw,getHeight()/vh);
            float width=vw*scale,height=vh*scale;
            return new RectF((getWidth()-width)/2f,(getHeight()-height)/2f,(getWidth()+width)/2f,(getHeight()+height)/2f);
        }
        @Override protected void onDraw(Canvas canvas){
            super.onDraw(canvas);
            if(!isEnabled())return;
            RectF r=area();
            float l=r.left+x*r.width(),t=r.top+y*r.height(),right=l+w*r.width(),bottom=t+h*r.height();
            paint.setColor(0x5546D9BC);paint.setStyle(Paint.Style.FILL);canvas.drawRect(l,t,right,bottom,paint);
            paint.setColor(0xFF46D9BC);paint.setStrokeWidth(3f);paint.setStyle(Paint.Style.STROKE);canvas.drawRect(l,t,right,bottom,paint);
        }
        private float bound(float f){return Math.max(0f,Math.min(1f,f));}
        @Override public boolean onTouchEvent(MotionEvent event){
            if(!isEnabled())return false;
            RectF r=area();
            float px=bound((event.getX()-r.left)/Math.max(1,r.width()));
            float py=bound((event.getY()-r.top)/Math.max(1,r.height()));
            if(event.getActionMasked()==MotionEvent.ACTION_DOWN){downX=px;downY=py;return true;}
            if(event.getActionMasked()==MotionEvent.ACTION_MOVE || event.getActionMasked()==MotionEvent.ACTION_UP){
                x=Math.min(px,downX);y=Math.min(py,downY);w=Math.max(.004f,Math.abs(px-downX));h=Math.max(.004f,Math.abs(py-downY));
                w=Math.min(w,1-x);h=Math.min(h,1-y);
                invalidate();
                if(event.getActionMasked()==MotionEvent.ACTION_UP && onRectangle!=null)onRectangle.onSelection(x,y,w,h);
                return true;
            }
            return false;
        }
    }
}
