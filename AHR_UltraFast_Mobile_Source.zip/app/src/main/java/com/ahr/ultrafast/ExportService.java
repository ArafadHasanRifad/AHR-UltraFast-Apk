package com.ahr.ultrafast;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;
import android.os.SystemClock;
import androidx.annotation.Nullable;
import androidx.media3.common.C;
import androidx.media3.common.Effect;
import androidx.media3.common.MediaItem;
import androidx.media3.common.util.UnstableApi;
import androidx.media3.effect.BitmapOverlay;
import androidx.media3.effect.OverlayEffect;
import androidx.media3.effect.StaticOverlaySettings;
import androidx.media3.effect.TextureOverlay;
import androidx.media3.transformer.Composition;
import androidx.media3.transformer.EditedMediaItem;
import androidx.media3.transformer.Effects;
import androidx.media3.transformer.ExportException;
import androidx.media3.transformer.ExportResult;
import androidx.media3.transformer.ProgressHolder;
import androidx.media3.transformer.Transformer;
import java.io.File;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;

/** A foreground, single-export controller. No server uploads; input is read from selected URI. */
@UnstableApi
public final class ExportService extends Service {
    public static final String STATUS = "com.ahr.ultrafast.STATUS";
    public static final String START = "com.ahr.ultrafast.START";
    public static final String CANCEL = "com.ahr.ultrafast.CANCEL";
    private static final String CHANNEL = "export";
    private static final int NOTIF = 1701;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final ProgressHolder holder = new ProgressHolder();
    private Transformer transformer;
    private File output;
    private boolean running = false;
    private boolean stoppedByUser = false;
    private long began;
    private PowerManager.WakeLock wakeLock;
    private int lastProgress = -1;

    @Nullable @Override public IBinder onBind(Intent intent) { return null; }

    @Override public void onCreate() {
        super.onCreate();
        NotificationManager manager = getSystemService(NotificationManager.class);
        manager.createNotificationChannel(new NotificationChannel(CHANNEL, "Video export", NotificationManager.IMPORTANCE_LOW));
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent == null) return START_NOT_STICKY;
        if (CANCEL.equals(intent.getAction())) {
            stoppedByUser = true;
            if (transformer != null) transformer.cancel();
            finish("Cancelled", false);
            return START_NOT_STICKY;
        }
        if (!START.equals(intent.getAction())) return START_NOT_STICKY;
        if (running) { broadcast("An export is already running", -1, null); return START_NOT_STICKY; }
        startForeground(NOTIF, notification("Preparing export", 0));
        try { begin(intent); }
        catch (Exception e) { finish("Could not start: " + e.getMessage(), false); }
        return START_NOT_STICKY;
    }

    private void begin(Intent data) throws Exception {
        running = true;
        stoppedByUser = false;
        began = SystemClock.elapsedRealtime();
        lastProgress = -1;
        Uri source = Uri.parse(data.getStringExtra("source"));
        String label = data.getStringExtra("name");
        String text = data.getStringExtra("text");
        String logo = data.getStringExtra("logo");
        int startSeconds = data.getIntExtra("trimStart", 0);
        int endSeconds = data.getIntExtra("trimEnd", 0);
        boolean clone = data.getBooleanExtra("clone", false);
        float x = data.getFloatExtra("x", .83f), y = data.getFloatExtra("y", .02f);
        float w = data.getFloatExtra("w", .14f), h = data.getFloatExtra("h", .08f);
        float dx = data.getFloatExtra("dx", -.18f), dy = data.getFloatExtra("dy", 0f);

        File directory = getExternalFilesDir(Environment.DIRECTORY_MOVIES);
        if (directory == null || (!directory.exists() && !directory.mkdirs())) throw new IllegalStateException("Video output directory inaccessible");
        String sanitized = label == null ? "video" : label.replaceAll("[^a-zA-Z0-9_-]", "_");
        if (sanitized.length() > 36) sanitized = sanitized.substring(0, 36);
        output = new File(directory, "AHR_" + sanitized + "_" + System.currentTimeMillis() + ".mp4");

        MediaItem.Builder sourceBuilder = new MediaItem.Builder().setUri(source);
        if (startSeconds > 0 || endSeconds > 0) {
            MediaItem.ClippingConfiguration.Builder clip = new MediaItem.ClippingConfiguration.Builder()
                    .setStartPositionMs(startSeconds * 1000L);
            if (endSeconds > 0) clip.setEndPositionMs(endSeconds * 1000L);
            sourceBuilder.setClippingConfiguration(clip.build());
        }
        List<Effect> videoFx = new ArrayList<>();
        if (clone) {
            videoFx.add(new ClonePatchEffect(x,y,w,h,dx,dy));
        }
        List<TextureOverlay> overlays = new ArrayList<>();
        if (logo != null && !logo.isEmpty()) {
            Bitmap bitmap = decodeLogo(Uri.parse(logo));
            if (bitmap != null) {
                StaticOverlaySettings settings = new StaticOverlaySettings.Builder()
                        .setBackgroundFrameAnchor(.92f,.88f)
                        .setOverlayFrameAnchor(1f,1f)
                        .setAlphaScale(.90f).build();
                overlays.add(BitmapOverlay.createStaticBitmapOverlay(bitmap, settings));
            }
        }
        if (text != null && !text.trim().isEmpty()) {
            Bitmap bitmap = drawText(text.trim());
            StaticOverlaySettings settings = new StaticOverlaySettings.Builder()
                    .setBackgroundFrameAnchor(-.92f,-.88f)
                    .setOverlayFrameAnchor(-1f,-1f)
                    .setAlphaScale(.82f).build();
            overlays.add(BitmapOverlay.createStaticBitmapOverlay(bitmap, settings));
        }
        if (!overlays.isEmpty()) videoFx.add(new OverlayEffect(overlays));
        EditedMediaItem.Builder editBuilder = new EditedMediaItem.Builder(sourceBuilder.build());
        if (!videoFx.isEmpty()) editBuilder.setEffects(new Effects(Collections.emptyList(), videoFx));
        EditedMediaItem edited = editBuilder.build();
        // No effects: Media3 can often transmux. With a trim it first attempts minimal re-encoding.
        Transformer.Builder transformerBuilder = new Transformer.Builder(this)
                .experimentalSetTrimOptimizationEnabled(videoFx.isEmpty())
                .addListener(new Transformer.Listener() {
                    @Override public void onCompleted(Composition composition, ExportResult result) {
                        finish("Export complete", true);
                    }
                    @Override public void onError(Composition composition, ExportResult result, ExportException error) {
                        finish("Export failed: " + error.getMessage(), false);
                    }
                });
        transformer = transformerBuilder.build();
        PowerManager power = (PowerManager) getSystemService(POWER_SERVICE);
        wakeLock = power.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "AHR:Export");
        wakeLock.acquire(12L * 60 * 60 * 1000); // Android may still stop foreground services; not an infinite lock.
        transformer.start(edited, output.getAbsolutePath());
        broadcast(videoFx.isEmpty() ? "Fast copy / trim (when compatible)" : "GPU effects + hardware encoding", 0, null);
        handler.postDelayed(poll, 700);
    }

    private final Runnable poll = new Runnable() {
        @Override public void run() {
            if (!running || transformer == null) return;
            int state = transformer.getProgress(holder);
            if (state == Transformer.PROGRESS_STATE_AVAILABLE) {
                int percent = holder.progress;
                if (percent != lastProgress) {
                    lastProgress = percent;
                    long elapsed = (SystemClock.elapsedRealtime() - began) / 1000L;
                    long remain = percent > 0 ? (elapsed * (100L - percent) / percent) : -1;
                    String msg = "Exporting " + percent + "%" + (remain >= 0 ? " • ETA " + formatDuration(remain) : "");
                    broadcast(msg, percent, null);
                    getSystemService(NotificationManager.class).notify(NOTIF, notification(msg, percent));
                }
            }
            handler.postDelayed(this, 900);
        }
    };

    private static String formatDuration(long seconds) {
        return String.format(Locale.US,"%d:%02d:%02d",seconds/3600,(seconds/60)%60,seconds%60);
    }

    private Bitmap decodeLogo(Uri uri) {
        try (InputStream boundsStream = getContentResolver().openInputStream(uri)) {
            if (boundsStream == null) return null;
            BitmapFactory.Options options = new BitmapFactory.Options();
            options.inJustDecodeBounds = true;
            BitmapFactory.decodeStream(boundsStream, null, options);
            int max = Math.max(options.outWidth, options.outHeight);
            int sample = 1;
            while (max / sample > 512) sample *= 2;
            options = new BitmapFactory.Options();
            options.inSampleSize = sample;
            try (InputStream imageStream = getContentResolver().openInputStream(uri)) {
                return imageStream == null ? null : BitmapFactory.decodeStream(imageStream,null,options);
            }
        } catch (Exception e) { broadcast("Logo unreadable, skipped", -1, null); return null; }
    }

    private Bitmap drawText(String text) {
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setTypeface(Typeface.create(Typeface.DEFAULT, Typeface.BOLD));
        p.setTextSize(44f);
        String safe = text.length() > 70 ? text.substring(0,70) : text;
        int width = Math.max(60, Math.min(1920, (int) Math.ceil(p.measureText(safe) + 24)));
        Bitmap b = Bitmap.createBitmap(width, 68, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(b);
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(5);
        p.setColor(Color.BLACK);
        c.drawText(safe, 10,50,p);
        p.setStyle(Paint.Style.FILL);
        p.setColor(Color.WHITE);
        c.drawText(safe,10,50,p);
        return b;
    }

    private Notification notification(String value, int percent) {
        Intent open = new Intent(this, MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);
        PendingIntent pending = PendingIntent.getActivity(this,0,open,PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        Intent cancelIntent = new Intent(this,ExportService.class).setAction(CANCEL);
        PendingIntent cancel = PendingIntent.getService(this,2,cancelIntent,PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        Notification.Builder b = new Notification.Builder(this, CHANNEL)
                .setSmallIcon(android.R.drawable.stat_sys_upload)
                .setContentTitle("AHR UltraFast")
                .setContentText(value).setOnlyAlertOnce(true).setOngoing(true)
                .setContentIntent(pending).setProgress(100, percent, percent <= 0);
        if (running) b.addAction(new Notification.Action.Builder(android.R.drawable.ic_delete,"Cancel",cancel).build());
        return b.build();
    }

    private void broadcast(String message, int percent, String path) {
        Intent i = new Intent(STATUS).setPackage(getPackageName());
        i.putExtra("message",message); i.putExtra("percent",percent);
        if (path != null) i.putExtra("path",path);
        sendBroadcast(i);
    }

    private void finish(String message, boolean success) {
        if (!running && stoppedByUser) { stopSelf(); return; }
        running=false;
        handler.removeCallbacks(poll);
        if (wakeLock != null && wakeLock.isHeld()) wakeLock.release();
        if (!success && output != null && output.exists()) output.delete();
        String path = success && output != null ? output.getAbsolutePath() : null;
        if (success && path != null) getSharedPreferences("ahr", MODE_PRIVATE).edit().putString("lastPath", path).apply();
        broadcast(message, success ? 100 : -1, path);
        stopForeground(STOP_FOREGROUND_REMOVE);
        stopSelf();
        transformer = null;
    }

    @Override public void onDestroy() {
        handler.removeCallbacks(poll);
        if (transformer != null) transformer.cancel();
        if (wakeLock != null && wakeLock.isHeld()) wakeLock.release();
        super.onDestroy();
    }
}
