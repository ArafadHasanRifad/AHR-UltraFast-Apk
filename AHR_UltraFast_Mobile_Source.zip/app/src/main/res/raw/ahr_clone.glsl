precision highp float;
uniform sampler2D uTexSampler;
uniform vec4 uRect;   // x,y,w,h top-left normalized coordinates
uniform vec2 uShift;  // sample source shift from target (normalized)
varying vec2 vTexSamplingCoord;
void main() {
    vec2 current = vTexSamplingCoord;
    vec2 topCoord = vec2(current.x, 1.0 - current.y);
    if (topCoord.x >= uRect.x && topCoord.x < uRect.x + uRect.z &&
        topCoord.y >= uRect.y && topCoord.y < uRect.y + uRect.w) {
        vec2 src = clamp(topCoord + uShift, vec2(0.001), vec2(0.999));
        current = vec2(src.x, 1.0 - src.y);
    }
    gl_FragColor = texture2D(uTexSampler, current);
}
